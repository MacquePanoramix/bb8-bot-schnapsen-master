"""
RdeepBot - This bot looks ahead by following a random path down the game tree. That is,
 it assumes that all players have the same strategy as rand.py, and samples N random
 games following from a given move. It then ranks the moves by averaging the heuristics
 of the resulting states.
"""

# Import the API objects
from api import State
import random

class Node:
    #info of each node
    def __init__(self, depth, player_points, opponent_points, player_hand, opponent_hand, card, stock_left, player, opponent, card_number, parent, player_won, opponent_pair):
        self.depth = depth
        self.player_points = player_points
        self.opponent_points = opponent_points
        self.children = []
        self.parent = []
        self.parent.append(parent)
        self.player_hand = player_hand
        self.opponent_hand = opponent_hand
        self.card = card
        self.opponent_pair = []
        self.opponent_pair.append(opponent_pair)
        self.who_win_pair = []
        self.stock_left = stock_left
        self.player = player
        self.opponent = opponent
        self.card_number = card_number
        self.player_won = player_won
        self.already_counted = 0
        self.final_already_counted = 0
    def create_children(self, state):
        opponent_won = 2
        last_trick = 0
        if len(self.player_hand) == 0 and len(self.opponent_hand) == 0:
            last_trick = 1
        if self.parent[-1].opponent_pair[0] != 1:
            if self.pair_resulting_points(state, last_trick) <0:
                self.opponent_points += self.pair_resulting_points(state, last_trick) *-1
                opponent_won = 1
            else:
                self.player_points += self.pair_resulting_points(state, last_trick)
                opponent_won = 0
            if self.player_points >= 66:
                self.player_won = 1
                return "finished"
            elif self.opponent_points >= 66:
                self.player_won = -1
                return "finished"
            else:
                self.opponent_pair[0] = 1
        if opponent_won == 1:
            for card in self.opponent_hand:
                opponent_hand = self.opponent_hand.copy()
                opponent_hand.remove(card)
                stock_left = self.stock_left.copy()
                if len(stock_left) > 0:
                    card_added = random.choice(self.stock_left)
                    opponent_hand.append(card_added)
                    stock_left.remove(card_added)
                self.children.append(Node(self.depth+1, self.player_points, self.opponent_points, self.player_hand.copy(), opponent_hand, card, stock_left, self.player, self.opponent, self.opponent, self, 0, 0))
        elif opponent_won == 0:
            for card in self.player_hand:
                player_hand = self.player_hand.copy()
                player_hand.remove(card)
                stock_left = self.stock_left.copy()
                if len(stock_left) > 0:
                    card_added = random.choice(stock_left)
                    player_hand.append(card_added)
                    stock_left.remove(card_added)
                self.children.append(
                    Node(self.depth + 1, self.player_points, self.opponent_points, player_hand, self.opponent_hand.copy(),
                         card, stock_left, self.player, self.opponent, self.player, self, 0, 0))
        else:
            if self.card_number == self.player:
                for card in self.opponent_hand:
                    opponent_hand = self.opponent_hand.copy()
                    opponent_hand.remove(card)
                    stock_left = self.stock_left.copy()
                    if len(stock_left) > 0:
                        card_added = random.choice(self.stock_left)
                        opponent_hand.append(card_added)
                        stock_left.remove(card_added)
                    self.children.append(
                        Node(self.depth + 1, self.player_points, self.opponent_points, self.player_hand.copy(), opponent_hand,
                             card, stock_left, self.player, self.opponent, self.opponent, self, 0, 0))
            else:
                for card in self.player_hand:
                    player_hand = self.player_hand.copy()
                    player_hand.remove(card)
                    stock_left = self.stock_left.copy()
                    if len(stock_left) > 0:
                        card_added = random.choice(stock_left)
                        player_hand.append(card_added)
                        stock_left.remove(card_added)
                    self.children.append(
                        Node(self.depth + 1, self.player_points, self.opponent_points, player_hand, self.opponent_hand.copy(),
                             card, stock_left, self.player, self.opponent, self.player, self, 0, 0))
        return "not finished"
    def pair_resulting_points(self, state, last_trick):
        trump = state.get_trump_suit()
        cards_to_compare = self.create_cards_to_compare(self.card, self.parent[-1].card, self.card_number, self.parent[-1].card_number)
        resulting_points = self.compare_cards(trump, cards_to_compare, last_trick)
        return resulting_points

    def create_cards_to_compare(self, card1, card2, card1_player_number, card2_player_number):
        cards_to_compare = []
        cards = {0:"AC", 1:"10C", 2:"KC", 3:"QC", 4:"JC", 5:"AD", 6:'10D', 7:'KD', 8:'QD', 9:'JD', 10:'AH', 11:'10H', 12:'KH', 13:'QHY', 14:'JH', 15:'AS', 16:'10S', 17:'KS', 18:'QS', 19:'JS'}
        cards_to_compare.append(Card(cards.get(card1)[0], cards.get(card1)[-1], 2, card1_player_number))
        cards_to_compare.append(Card(cards.get(card2)[0], cards.get(card2)[-1], 1, card2_player_number))
        return cards_to_compare

    def compare_cards(self, trump, cards_to_compare, last_trick):
        all_ranks = []
        all_ranks.append(['J', 1])
        all_ranks.append(['Q', 2])
        all_ranks.append(['K', 3])
        all_ranks.append(['1', 10])
        all_ranks.append(['A', 11])
        card_0_rank = "0"
        card_1_rank = '0'
        for rank in all_ranks:
            if str(cards_to_compare[0].rank) == rank[0]:
                card_0_rank = rank[1]
        for rank in all_ranks:
            if str(cards_to_compare[1].rank) == rank[0]:
                card_1_rank = rank[1]
        if cards_to_compare[0].suit == trump and cards_to_compare[1].suit != trump:
            if cards_to_compare[0].player_number == self.player:
                if last_trick == 0:
                    return card_0_rank + card_1_rank
                else:
                    return 100
            else:
                if last_trick == 0:
                    return -card_0_rank - card_1_rank
                else:
                    return -100
        elif cards_to_compare[0].suit == trump and cards_to_compare[1].suit == trump:
            if card_1_rank > card_0_rank:
                if cards_to_compare[1].player_number == self.player:
                    if last_trick == 0:
                        return card_0_rank + card_1_rank
                    else:
                        return 100
                else:
                    if last_trick == 0:
                        return -card_0_rank - card_1_rank
                    else:
                        return -100
            else:
                if cards_to_compare[0].player_number == self.player:
                    if last_trick == 0:
                        return card_0_rank + card_1_rank
                    else:
                        return 100
                else:
                    if last_trick == 0:
                        return -card_0_rank
                    else:
                        return -100
        elif cards_to_compare[0].suit != trump and cards_to_compare[1].suit == trump:
            if cards_to_compare[1].player_number == self.player:
                if last_trick == 0:
                    return card_0_rank + card_1_rank
                else:
                    return 100
            else:
                if last_trick == 0:
                    return -card_0_rank - card_1_rank
                else:
                    return -100
        else:
            if cards_to_compare[0].suit != cards_to_compare[1].suit:
                if cards_to_compare[1].player_number == self.player:
                    if last_trick == 0:
                        return card_0_rank + card_1_rank
                    else:
                        return 100
                else:
                    if last_trick == 0:
                        return -card_0_rank - card_1_rank
                    else:
                        return -100
            else:
                if card_0_rank > card_1_rank:
                    if cards_to_compare[0].player_number == self.player:
                        if last_trick == 0:
                            return card_0_rank + card_1_rank
                        else:
                            return 100
                    else:
                        if last_trick == 0:
                            return -card_0_rank - card_1_rank
                        else:
                            return -100
                else:
                    if cards_to_compare[1].player_number == self.player:
                        if last_trick == 0:
                            return card_0_rank + card_1_rank
                        else:
                            return 100
                    else:
                        if last_trick == 0:
                            return -card_0_rank - card_1_rank
                        else:
                            return -100

class Card:

    def __init__(self, rank, suit, order, player_number):
        self.suit = suit
        self.rank = rank
        self.order = order
        self.player_number = player_number











class Bot:

    # How many samples to take per move
    __num_samples = -1
    # How deep to sample
    __depth = -1
    turn = -1
    def __init__(self, num_samples=4, depth=8, turn=0):
        self.__num_samples = num_samples
        self.__depth = depth
        self.turn = turn

    def get_move(self, state):

        # See if we're player 1 or 2
        player = state.whose_turn()

        # Get a list of all legal moves
        moves = state.moves()

        # Sometimes many moves have the same, highest score, and we'd like the bot to pick a random one.
        # Shuffling the list of moves ensures that.
        random.shuffle(moves)

        best_score = float("-inf")
        best_move = None

        scores = [0.0] * len(moves)

        for move in moves:
            for s in range(self.__num_samples):

                # If we are in an imperfect information state, make an assumption.

                sample_state = state.make_assumption() if state.get_phase() == 1 else state

                score = self.evaluate(sample_state.next(move), player)

                if score > best_score:
                    best_score = score
                    best_move = move
        self.turn += 1
        return best_move # Return the best scoring move

    def evaluate(self,
                 state,     # type: State
                 player,     # type: int

            ):
        # type: () -> float
        """
        Evaluates the value of the given state for the given player
        :param state: The state to evaluate
        :param player: The player for whom to evaluate this state (1 or 2)
        :return: A float representing the value of this state for the given player. The higher the value, the better the
            state is for the player.
        """
        score = 0.0
        st = state.clone()
        turn = self.turn

        # Do some random moves
        for i in range(self.__depth):
            if st.finished():
                break

            if turn <7:
                turn += 1
                st = st.next(random.choice(st.moves()))
            else:
                score = self.minmax(st, player)
                break

        return score


    def minmax(self, state, player):
        hand = state.get_player_card(player)
        player_number = player
        if player_number == 1:
            opponent_number = 2
        else:
            opponent_number = 1
        current_player = state.whose_turn()
        if current_player == 1:
            other_player = 2
        else:
            other_player = 1
        previous_card = state.get_prev_trick()[-1]
        op_hand = state.get_player_card(opponent_number)
        stock_left = state.remaining_cards_in_deck()
        initial_nodes = self.create_initial_nodes(hand, state, player_number, opponent_number, op_hand, stock_left, current_player, other_player, previous_card)
        final_children_variable = []
        final_children = self.create_all_children(state, initial_nodes, final_children_variable)
        return self.perform_minimax(final_children)




    def create_initial_nodes(self, hand, state, player_number, opponent_number, op_hand, stock_left, current_player, other_player, previous_card):
        initial_nodes = []
        if current_player == player_number:
            for card in hand:
                node_card = card
                node_stock_left = stock_left.copy()
                node_hand = hand.copy()
                node_hand.remove(node_card)
                if len(stock_left) > 0:
                    node_card_added = random.choice(stock_left)
                    node_hand.append(node_card_added)
                    node_stock_left.remove(node_card_added)
                initial_nodes.append(Node(0, state.get_points(player_number), state.get_points(opponent_number), node_hand, op_hand.copy(), node_card, node_stock_left, player_number, opponent_number, current_player, Node(-1, state.get_points(player_number), state.get_points(opponent_number), hand, op_hand, previous_card, stock_left, player_number, opponent_number, other_player, 0, 0, 1), 0, 0))
            return initial_nodes
        else:
            for card in op_hand:
                node_card = card
                node_stock_left = stock_left.copy()
                node_hand = op_hand.copy()
                node_hand.remove(node_card)
                if len(stock_left) > 0:
                    node_card_added = random.choice(stock_left)
                    node_hand.append(node_card_added)
                    node_stock_left.remove(node_card_added)
                initial_nodes.append(Node(0, state.get_points(player_number), state.get_points(opponent_number), hand.copy(), node_hand, node_card, node_stock_left, player_number, opponent_number, current_player, Node(-1, state.get_points(player_number), state.get_points(opponent_number), hand, op_hand, previous_card, stock_left, player_number, opponent_number, other_player, 0, 0, 1), 0, 0))
            return initial_nodes

    def create_all_children(self, state, initial_nodes, final_children):
        for node in initial_nodes:
            if node.create_children(state) != "finished":
                final_children = self.create_all_children(state, node.children, final_children)
            final_children.append(node)
        return final_children

    def perform_minimax(self, final_children):
        max_depth = 0
        current_children = []
        for children in final_children:
            if children.final_already_counted == 0:
                if children.depth > max_depth:
                    max_depth = children.depth
        for children in final_children:
            if children.final_already_counted == 0:
                if children.depth == max_depth:
                    current_children.append(children)
                    children.final_already_counted = 1
        for children in current_children:
            if children.already_counted == 0:
                parent = children.parent[-1]
                parent_children = parent.children
                current_layer_score = []
                for child in parent_children:
                    child.already_counted = 1
                    children_card_number = child.card_number
                    current_layer_score.append(child.player_won)
                if children_card_number == parent_children[0].player:
                    player_lose = 1
                    for score in current_layer_score:
                        if score == 1:
                            player_lose = 0
                            parent.player_won = 1
                    if player_lose == 1:
                        parent.player_won = -1
                else:
                    opponent_lose = 1
                    for score in current_layer_score:
                        if score == -1:
                            parent.player_won = -1
                            opponent_lose = 0
                    if  opponent_lose == 1:
                        parent.player_won = 1
        if current_children[0].depth == 1:
            return current_children[0].player_won
        return self.perform_minimax((final_children))









